import React from 'react';
import Sidebarr from './sidebarr'; // Import the sidebar for People
import Tablep from './tablep'; // Import the table for People

const PeopleLayout = () => {
  return (
    <>
      <div className="user--info">
        <input type="text" placeholder="search" />
      </div>
      <section className="content">
        <h1>People</h1> {/* Change the title to 'People' */}
        <Sidebarr /> {/* Render the sidebar for People */}
        <Tablep /> {/* Render the table for People */}
      </section>
    </>
  );
};

export default PeopleLayout;
