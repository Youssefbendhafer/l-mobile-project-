import React from 'react';
import Sidebar from './sidebar';
import Table from './table';

const Layout = () => {
  return (
    <><div className="user--info">
          <input type="text" placeholder="search" />
      </div><section className="content">
              <h1>Articles</h1>
              <Sidebar></Sidebar>
              <Table></Table>
          </section></>
  );
};

export default Layout;
